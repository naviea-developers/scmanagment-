<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\AcademicYear;
use App\Models\Admission;
use App\Models\Category;
use App\Models\Course;
use App\Models\CourseCareerOutcome;
use App\Models\CourseConten;
use App\Models\CourseLanguage;
use App\Models\CourseLearn;
use App\Models\CourseLesson;
use App\Models\CourseLessonFile;
use App\Models\CourseLessonVideo;
use App\Models\CourseQuizFile;
use App\Models\CourseRequisite;
use App\Models\CourseResourceFile;
use App\Models\CourseSave;
use App\Models\CourseSkill;
use App\Models\CoursezprojectFile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\RelatedCourse;
use App\Models\HomeWork;
use App\Models\Classe;
use App\Models\Subject;
use App\Models\Examination;
use App\Models\ClassTestExam;
use App\Models\ExamClass;
use App\Models\ExamResult;
use App\Models\SchoolSection;
use App\Models\Session;
use App\Models\Student;
use App\Models\SubjectTeacherAssent;
use App\Models\DailyClass;
use App\Models\User;
use App\Models\Group;
use App\Models\Lession;
use App\Models\Section;

class InstructorCourseController extends Controller
{
    public function manageCourse()
    {
        $data['courses'] = Course::where('teacher_id', auth()->user()->id)->orderBy('id','desc')->get();
        return view('user.instructor.course_index', $data);
    }
    public function addCourse()
    {
        $data["master_categories"] = Category::where('parent_id', '=' ,0)->where('type','master_course')->get();
        // $data['teachers'] = User::where('type','2')->orderBy('id', 'desc')->get();
        $data["categorys"] = Category::where('parent_id', '=' ,0)->where('type','home')->get();
        $data["sub_categories"] = Category::where('parent_id', '!=' ,0)->where('type','home')->where('is_sub',0)->orderBy('id', 'desc')->get();
        $data['languages'] = CourseLanguage::orderBy('id', 'desc')->where('status',1)->get();
        $data['courses'] = Course::where('teacher_id',auth()->user()->id )->where('is_master', 0)->orderBy('id','desc')->get();
        //dd('hi');
        return view('user.instructor.course_create', $data);
    }
    
    public function storCourse(Request $request)
    {
        try{
            DB::beginTransaction();

            $course = New Course();
            // $car->slug = SlugService::createSlug(Car::class, 'slug', $request->name);
            if($request->general_category_id){
                $course->category_id = $request->general_category_id;
            }
            if($request->master_category_id){
                $course->category_id = $request->master_category_id;
            }
            $course->sub_category_id = $request->general_sub_category_id ?? 0;
            $course->teacher_id = auth()->user()->id ?? 0;
            $course->name = $request->name ?? "";
            // $course->subject = $request->subject ?? "";
            // $course->pre_fee = $request->discount;
            $course->fee = $request->fee;
            $course->discount =  $request->discount;
            $course->discounttype =  $request->discounttype;
            $course->organization_name =  $request->organization_name;
            $course->course_hours =  $request->course_hours;
            $course->course_level = $request->course_level ?? "";
            $course->coursetype = $request->coursetype;
            $course->trailer_video_url = $request->trailer_video_url ?? "";
            $course->is_master = $request->is_master;
    
            $course->about = $request->about ?? "";
            $course->save();
    
    
        if($request->language){
            foreach( $request->language as $value){
                $courselanguage = new CourseLanguage();
                $courselanguage->course_id = $course->id;
                $courselanguage->name = $value;
                $courselanguage->type = 'course';
                $courselanguage->save();
            }
        }
    
    
        if($request->relatedcourse_id){
            foreach( $request->relatedcourse_id as $value){
                $relatedcourse = new RelatedCourse();
                $relatedcourse->course_id = $course->id;
                $relatedcourse->relatedcourse_id = $value;
                $relatedcourse->save();
            }
        }
    
    
           //   Topics for this course Start
           if($request->capter_name){
    
            foreach($request->capter_name as $k=>$value){
                $courselesson= New CourseLesson;
                $courselesson->course_id=$course->id;
                $courselesson->capter_name = $value;
                $courselesson->save();
    
                foreach($request->lesson_names[$k] as $j=>$value){
                    $courselessonvideo= New CourseLessonVideo;
                    $courselessonvideo->course_lesson_id=$courselesson->id;
                     $courselessonvideo->lesson_video="https://" . preg_replace('#^https?://#', '',$request->lesson_videos[$k][$j]);
                     $courselessonvideo->lesson_name=$request->lesson_names[$k][$j];
                     $courselessonvideo->video_time=$request->video_time[$k][$j];
                    $courselessonvideo->save();
                   }
    
            }
        }
        // Topics for this course End
    
             //Course resource file Start
             if($request->resourcefile){
             foreach($request->file('resourcefile') as $k=>$value){
                $courseresourcefile= New CourseResourceFile;
                $courseresourcefile->course_id=$course->id;
    
                $filename=time().$k.'resourcefile'.'.'.$value->getClientOriginalName();
                $value->move(public_path('upload/course/file/'), $filename);
                 $courseresourcefile->name=$filename;
                 
                $courseresourcefile->save();
               }
            }
            //Course resource file End
    
             //Course lesson file Start
             if($request->lessonfile){
                foreach($request->file('lessonfile') as $k=>$value){
                   $courselessonfile= New CourseLessonFile;
                   $courselessonfile->course_id=$course->id;
                   $filename=time().$k.'lessonfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $courselessonfile->name=$filename;
                   $courselessonfile->save();
                  }
               }
            //Course lesson file End
    
             //Course Quiz file Start
             if($request->quizfile){
                foreach($request->file('quizfile') as $k=>$value){
                   $coursequizfile= New CourseQuizFile;
                   $coursequizfile->course_id=$course->id;
                   $filename=time().$k.'quizfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $coursequizfile->name=$filename;
                   $coursequizfile->save();
                  }
               }
            //Course Quiz file End
    
             //Course projectfile file Start
             if($request->projectfile){
                foreach($request->file('projectfile') as $k=>$value){
                   $courseprojectfile= New CoursezprojectFile;
                   $courseprojectfile->course_id=$course->id;
                   $filename=time().$k.'projectfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $courseprojectfile->name=$filename;
                   $courseprojectfile->save();
                  }
               }
            //Course projectfile file End
    
            //CourseRequisite Start
            if($request->requisites){
                foreach( $request->requisites as $value){
                    $courserequisite = new CourseRequisite();
                    $courserequisite->course_id = $course->id;
                    $courserequisite->name = $value;
                    $courserequisite->save();
                }
            }
            //CourseRequisite End
    
            //CourseLearn Start
            if($request->course_learn){
                foreach( $request->course_learn as $value){
                    $courselearn = new CourseLearn();
                    $courselearn->course_id = $course->id;
                    $courselearn->name = $value;
                    $courselearn->save();
                }
            }
            //CourseLearn End
    
              //CourseCareerOutcome Start
              if($request->course_outcome){
                foreach( $request->course_outcome as $value){
                    $course_outcome = new CourseCareerOutcome();
                    $course_outcome->course_id = $course->id;
                    $course_outcome->name = $value;
                    $course_outcome->save();
                }
             }
            //CourseCareerOutcome End
    
            //CourseSkill Start
            if($request->course_skill){
                foreach( $request->course_skill as $value){
                    $course_skill = new CourseSkill();
                    $course_skill->course_id = $course->id;
                    $course_skill->name = $value;
                    $course_skill->save();
                }
            }
            //CourseSkill End
    
             //CourseConten Start
             //dd($request->conten_name);
             if($request->conten_name){
                foreach( $request->conten_name as $k=>$value){
                    $courseconten = new CourseConten();
                    $courseconten->course_id = $course->id;
                    $courseconten->name = $value;
                    $courseconten->conten_url = $request->conten_url[$k];
                    $courseconten->save();
                }
            }

        DB::commit();
        return redirect()->route('instructor.manage_course')->with('message','Course Create Successfully');
         }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }
    public function editCourse($id)
    {   $data['course']=Course::find($id);
        $data["master_categories"] = Category::where('parent_id', '=' ,0)->where('type','master_course')->get();
        // $data['teachers'] = User::where('type','2')->orderBy('id', 'desc')->get();
        $data["categories"] = Category::where('parent_id',0)->where('type','home')->get();
        $data["sub_categories"] = Category::where('parent_id', '!=' ,0)->where('type','home')->where('is_sub',0)->orderBy('id', 'desc')->get();
        $data['languages'] = CourseLanguage::orderBy('id', 'desc')->where('status',1)->get();
        $data['courses'] = Course::where('teacher_id',auth()->user()->id )->where('is_master', 0)->orderBy('id','desc')->get();
        return view('user.instructor.course_update', $data);
    }
    public function updateCourse(Request $request, $id)
    {
        try{
            DB::beginTransaction();

            $course = Course::find($id);
            // $car->slug = SlugService::createSlug(Car::class, 'slug', $request->name);
            // $course->category_id = $request->category_id ?? 0;
            if($request->general_category_id){
                $course->category_id = $request->general_category_id;
            }
            if($request->master_category_id){
                $course->category_id = $request->master_category_id;
            }
    
            $course->sub_category_id = $request->general_sub_category_id ?? 0;
            // $course->sub_category_id = $request->sub_category_id ?? 0;
            $course->teacher_id = auth()->user()->id ?? 0;
            $course->name = $request->name ?? "";
            // $course->subject = $request->subject ?? "";
            // $course->pre_fee = $request->pre_fee;
            $course->fee = $request->fee;
            $course->discount =  $request->discount;
            $course->discounttype =  $request->discounttype;
            $course->organization_name =  $request->organization_name;
            $course->course_level = $request->course_level ?? "";
            $course->coursetype = $request->coursetype;
            $course->course_hours =  $request->course_hours;
            $course->trailer_video_url = $request->trailer_video_url ?? "";
            $course->is_master = $request->is_master;
            $course->about = $request->about ?? "";
    
          $course->save();
    
        RelatedCourse::where('course_id',$id)->get()->each->delete();
        // dd($request->type_age);
        if($request->relatedcourse_id){
            foreach( $request->relatedcourse_id as $value){
                $relatedcourse = new RelatedCourse();
                $relatedcourse->course_id = $course->id;
                $relatedcourse->relatedcourse_id = $value;
                $relatedcourse->save();
            }
        }
    
    
        CourseLanguage::where('course_id',$id)->get()->each->delete();
    
        if($request->language){
            foreach( $request->language as $value){
                $courselanguage = new CourseLanguage();
                $courselanguage->course_id = $course->id;
                $courselanguage->name = $value;
                $courselanguage->type = 'course';
                $courselanguage->save();
            }
        }
    
         // Topics for this course Start
         if($request->capter_name){
            foreach($request->capter_name as $k=>$value){
                $courselesson= New CourseLesson;
                $courselesson->course_id=$course->id;
                $courselesson->capter_name = $value;
                $courselesson->save();
    
                foreach($request->lesson_names[$k] as $j=>$value){
                    $courselessonvideo= New CourseLessonVideo;
                    $courselessonvideo->course_lesson_id=$courselesson->id;
                     $courselessonvideo->lesson_video="https://" . preg_replace('#^https?://#', '',$request->lesson_videos[$k][$j]);
                     $courselessonvideo->lesson_name=$request->lesson_names[$k][$j];
                     $courselessonvideo->video_time=$request->video_time[$k][$j];
                    $courselessonvideo->save();
                   }
            }
        }
    
        //Topics for this course End
        if($request->old_capter_name){
    
            foreach($request->old_capter_name as $k=>$value){
                $courselesson=CourseLesson::find($k);
                $courselesson->course_id=$course->id;
                $courselesson->capter_name = $value;
                $courselesson->save();
    
               foreach($request->old_lesson_names[$k] as $j=>$value){
                $courselessonvideo= CourseLessonVideo::find($j);
                $courselessonvideo->course_lesson_id=$courselesson->id;
                $courselessonvideo->lesson_video="https://" . preg_replace('#^https?://#', '',$request->old_lesson_videos[$k][$j]);
                $courselessonvideo->lesson_name=$request->old_lesson_names[$k][$j];
                $courselessonvideo->video_time=$request->old_video_time[$k][$j];
                $courselessonvideo->save();
               }
    
               if(isset($request->lesson_names[$k])){
               foreach($request->lesson_names[$k] as $j=>$value){
                $courselessonvideo= New CourseLessonVideo;
                $courselessonvideo->course_lesson_id=$courselesson->id;
                 $courselessonvideo->lesson_video="https://" . preg_replace('#^https?://#', '',$request->lesson_videos[$k][$j]);
                 $courselessonvideo->lesson_name=$request->lesson_names[$k][$j];
                 $courselessonvideo->video_time=$request->video_time[$k][$j];
                $courselessonvideo->save();
               }
            }
    
            }
        }
    
          //dd($request->all());
          if($request->delete_courselessonvideo){
            foreach($request->delete_courselessonvideo as $value){
                $courselessonvideo= CourseLessonVideo::find($value);
                $courselessonvideo->delete();
            }
          }
    
        if($request->delete_courselesson){
            foreach($request->delete_courselesson as $val){
                $courselesson= CourseLesson::find($val);
    
                foreach($courselesson->courselessonvideos as $courselessonvideo){
                    @unlink(public_path('upload/coursevideo/'.$courselessonvideo->lesson_video));
                    $courselessonvideo->delete();
                }
                $courselesson->delete();
            }
        }
    
        //Topics for this course End
    
          //Course resource file Start
          if($request->resourcefile){
          foreach($request->file('resourcefile') as $k=>$value){
            $courseresourcefile= New CourseResourceFile;
            $courseresourcefile->course_id=$course->id;
            $filename=time().$k.'resourcefile'.'.'.$value->getClientOriginalName();
            $value->move(public_path('upload/course/file/'), $filename);
             $courseresourcefile->name=$filename;
            $courseresourcefile->save();
           }
        }
    
        if($request->old_resourcefile){
            foreach($request->file('old_resourcefile') as $k=>$value){
              $courseresourcefile=CourseResourceFile::find($k);
              @unlink(public_path('upload/course/file/'.$courseresourcefile->name));
              $courseresourcefile->course_id=$course->id;
              $filename=time().$k.'resourcefile'.'.'.$value->getClientOriginalName();
              $value->move(public_path('upload/course/file/'), $filename);
               $courseresourcefile->name=$filename;
              $courseresourcefile->save();
             }
          }
    
        if($request->delete_resourcefile){
            foreach($request->delete_resourcefile as $k => $value){
                $courseresourcefile = CourseResourceFile::find($value);
                @unlink(public_path('upload/course/file/'.$courseresourcefile->name));
                $courseresourcefile->delete();
    
            }
        }
        //Course resource file End
    
            //Course lesson file Start
            if($request->lessonfile){
                foreach($request->file('lessonfile') as $k=>$value){
                   $courselessonfile= New CourseLessonFile;
                   $courselessonfile->course_id=$course->id;
                   $filename=time().$k.'lessonfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $courselessonfile->name=$filename;
                   $courselessonfile->save();
                  }
               }
    
            if($request->old_lessonfile){
                foreach($request->file('old_lessonfile') as $k=>$value){
                   $courselessonfile=CourseLessonFile::find($k);
                   @unlink(public_path('upload/course/file/'.$courselessonfile->name));
                   $courselessonfile->course_id=$course->id;
                   $filename=time().$k.'lessonfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $courselessonfile->name=$filename;
                   $courselessonfile->save();
                  }
               }
    
    
            if($request->delete_lessonfile){
                foreach($request->delete_lessonfile as $k => $value){
                    $courselessonfile = CourseLessonFile::find($value);
                    @unlink(public_path('upload/course/file/'.$courselessonfile->name));
                    $courselessonfile->delete();
    
                }
            }
            //Course lesson file End
    
            //Course Quiz file Start
            if($request->quizfile){
                foreach($request->file('quizfile') as $k=>$value){
                   $coursequizfile= New CourseQuizFile;
                   $coursequizfile->course_id=$course->id;
                   $filename=time().$k.'quizfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $coursequizfile->name=$filename;
                   $coursequizfile->save();
                  }
               }
    
            if($request->old_quizfile){
                foreach($request->file('old_quizfile') as $k=>$value){
                   $coursequizfile=CourseQuizFile::find($k);
                   @unlink(public_path('upload/course/file/'.$coursequizfile->name));
                   $coursequizfile->course_id=$course->id;
                   $filename=time().$k.'quizfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $coursequizfile->name=$filename;
                   $coursequizfile->save();
                  }
               }
    
            if($request->delete_quizfile){
                foreach($request->delete_quizfile as $k => $value){
                    $coursequizfile = CourseQuizFile::find($value);
                    @unlink(public_path('upload/course/file/'.$coursequizfile->name));
                    $coursequizfile->delete();
    
                }
            }
            //Course Quiz file End
    
            //Course projectfile file Start
    
            if($request->projectfile){
                foreach($request->file('projectfile') as $k=>$value){
                   $courseprojectfile= New CoursezprojectFile;
                   $courseprojectfile->course_id=$course->id;
                   $filename=time().$k.'projectfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $courseprojectfile->name=$filename;
                   $courseprojectfile->save();
                  }
               }
    
               if($request->old_projectfile){
                foreach($request->file('old_projectfile') as $k=>$value){
                   $courseprojectfile= CoursezprojectFile::find($k);
                   @unlink(public_path('upload/course/file/'.$courseprojectfile->name));
                   $courseprojectfile->course_id=$course->id;
                   $filename=time().$k.'projectfile'.'.'.$value->getClientOriginalName();
                   $value->move(public_path('upload/course/file/'), $filename);
                    $courseprojectfile->name=$filename;
                   $courseprojectfile->save();
                  }
               }
    
            if($request->delete_projectfile){
                foreach($request->delete_projectfile as $k => $value){
                    $courseprojectfile = CoursezprojectFile::find($value);
                    @unlink(public_path('upload/course/file/'.$courseprojectfile->name));
                    $courseprojectfile->delete();
    
                }
            }
            //Course projectfile file End
    
            //CourseRequisite Start
            if($request->requisites){
                foreach( $request->requisites as $value){
                    $courserequisite = new CourseRequisite();
                    $courserequisite->course_id = $course->id;
                    $courserequisite->name = $value;
                    $courserequisite->save();
                }
            }
    
            if($request->old_requisites){
                foreach($request->old_requisites as $k=> $value){
                    $courserequisite = CourseRequisite::find($k);
                    $courserequisite->course_id = $course->id;
                    $courserequisite->name = $value;
                    $courserequisite->save();;
                }
            }
    
            if($request->delete_courserequisite){
                foreach($request->delete_courserequisite as $k => $value){
                    $courserequisite = CourseRequisite::find($value);
                    $courserequisite->delete();
    
                }
            }
    
             //CourseRequisite End
    
            //CourseLearn Start
            if($request->course_learn){
                foreach( $request->course_learn as $value){
                    $courselearn = new CourseLearn();
                    $courselearn->course_id = $course->id;
                    $courselearn->name = $value;
                    $courselearn->save();
                }
            }
    
            if($request->old_course_learn){
                foreach($request->old_course_learn as $k=> $value){
                    $courselearn = CourseLearn::find($k);
                    $courselearn->course_id = $course->id;
                    $courselearn->name = $value;
                    $courselearn->save();;
                }
            }
    
            if($request->delete_learn){
                foreach($request->delete_learn as $k => $value){
                    $courselearn = CourseLearn::find($value);
                    $courselearn->delete();
    
                }
            }
           //CourseRequisite End
    
    
              //CourseCareerOutcome
              if($request->course_outcome){
                foreach( $request->course_outcome as $value){
                    $course_outcome = new CourseCareerOutcome();
                    $course_outcome->course_id = $course->id;
                    $course_outcome->name = $value;
                    $course_outcome->save();
                }
            }
    
            if($request->old_course_outcome){
                foreach($request->old_course_outcome as $k=> $value){
                    $course_outcome = CourseCareerOutcome::find($k);
                    $course_outcome->course_id = $course->id;
                    $course_outcome->name = $value;
                    $course_outcome->save();;
                }
            }
    
            if($request->delete_outcome){
                foreach($request->delete_outcome as $k => $value){
                    $course_outcome = CourseCareerOutcome::find($value);
                    $course_outcome->delete();
    
                }
            }
            //CourseCareerOutcome End
    
    
            //CourseSkill Start
            if($request->course_skill){
                foreach( $request->course_skill as $value){
                    $course_skill = new CourseSkill();
                    $course_skill->course_id = $course->id;
                    $course_skill->name = $value;
                    $course_skill->save();
                }
            }
    
            if($request->old_course_skill){
                foreach($request->old_course_skill as $k=> $value){
                    $course_skill = CourseSkill::find($k);
                    $course_skill->course_id = $course->id;
                    $course_skill->name = $value;
                    $course_skill->save();;
                }
            }
    
            if($request->delete_skill){
                foreach($request->delete_skill as $k => $value){
                    $course_skill = CourseSkill::find($value);
                    $course_skill->delete();
    
                }
            }
    
            //CourseSkill End
    
    
            //CourseConten Start
    
            if($request->conten_name){
    
                foreach( $request->conten_name as $k=>$value){
                    $courseconten = new CourseConten();
                    $courseconten->course_id = $course->id;
                    $courseconten->name = $value;
                    $courseconten->conten_url = $request->conten_url[$k];
                    $courseconten->save();
                }
            }
            if($request->old_conten_name){
                foreach($request->old_conten_name as $k => $value){
                    $courseconten = CourseConten::find($k);
                    $courseconten->course_id = $course->id;
                    $courseconten->name = $value;
                    $courseconten->conten_url = $request->old_conten_url[$k];
                    $courseconten->save();
                }
            }
    
            if($request->delete_conten){
                foreach($request->delete_conten as $key => $value){
                    $courseconten = CourseConten::find($value);
                    $courseconten->delete();
    
                }
            }
    
             //CourseConten  End

        DB::commit();
        return redirect()->route('instructor.manage_course')->with('message','Course Update Successfully');
         }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }   
    }


    public function deleteCourse(Request $request)
    {
        //dd($request->all());
        $course = Course::find($request->course_id);
          @unlink(public_path('upload/course/'.$course->image));

        foreach($course->courserequisites as $courserequisite){
            $courserequisite->delete();
        }

        foreach($course->courselearns as $courselearn){
            $courselearn->delete();
        }

        foreach($course->courselanguages as $item){
            $item->delete();
        }

        foreach($course->coursecareeroutcomes as $coursecareeroutcome){
            $coursecareeroutcome->delete();
        }

        foreach($course->courseskills as $courseskill){
            $courseskill->delete();
        }
        foreach($course->course_content as $item){
            $item->delete();
        }

        foreach($course->courselessonfiles as $courselessonfile){
            @unlink(public_path('upload/course/file/'.$courselessonfile->name));
            $item->delete();
        }

        foreach($course->courseresourcefiles as $courseresourcefile){
            @unlink(public_path('upload/course/file/'.$courseresourcefile->name));
            $item->delete();
        }

        foreach($course->coursequizfiles as $coursequizfile){
            @unlink(public_path('upload/course/file/'.$coursequizfile->name));
            $item->delete();
        }

        foreach($course->courseprojectfiles as $courseprojectfile){
            @unlink(public_path('upload/course/file/'.$courseprojectfile->name));
            $item->delete();
        }

        foreach($course->courselessons as $courselesson){

            foreach($courselesson->courselessonvideos as $courselessonvideo){
                @unlink(public_path('upload/coursevideo/'.$courselessonvideo->lesson_video));
                $courselessonvideo->delete();
            }
            $courselesson->delete();
        }


        $course->delete();
        return back()->with('message','Course Deleted Successfully');
    }

   // home work start

    public function indexHomeWork()
    {
         //dd('hi');
         $data['session']=$currentSession = Session::where('is_current', 1)->first();
         $data['home_works'] = HomeWork::where('teacher_id', auth()->user()->id)
                                         ->where('session_id',$currentSession->id)
                                         ->orderBy('id','desc')
                                         ->get();
        // $data['home_works'] = HomeWork::where('teacher_id', auth()->user()->id)->orderBy('id','desc')->get();

        return view('user.instructor.home_worke_index', $data);
    }

    public function createHomeWork()
    {
        // dd('hi');
        $data['sessions']=Session::orderBy('id', 'desc')->where('status', 1)->get();
        // $data['subjects']=Subject::orderBy('id', 'desc')->where('status', 1)->get();

        // $data['teacherAssents']=SubjectTeacherAssent::where('teacher_id', auth()->user()->id)->orderBy('id', 'desc')->where('status', 1)->get(); 
        // $data['classes']=Classe::orderBy('id', 'desc')->where('status', 1)->get(); 

        $data['teacherAssents'] = SubjectTeacherAssent::where('teacher_id', auth()->user()->id)
        ->where('status', 1)
        ->orderBy('id', 'desc')
        ->get();

        $classIds = $data['teacherAssents']->pluck('class_id')->unique();

        $data['classs'] = Classe::whereIn('id', $classIds)
        ->where('status', 1)
        ->orderBy('id', 'desc')
        ->get();
       
        return view('user.instructor.home_worke_create', $data);
    }

    public function getSectionsAndSubjects(Request $request)
    {
        $classId = $request->class_id;
        $sectionId = $request->section_id ?? null;
        $teacherId = auth()->user()->id;
    
        $sectionIds = SubjectTeacherAssent::where('teacher_id', $teacherId)
            ->where('class_id', $classId)
            ->pluck('section_id');
        $sections = SchoolSection::whereIn('id', $sectionIds)->get();
    
        $query = SubjectTeacherAssent::where('teacher_id', $teacherId)
            ->where('class_id', $classId);
    
        if ($sectionId) {
            $query->where('section_id', $sectionId);
        }
    
        $subjectIds = $query->pluck('subject_id');
        $subjects = Subject::whereIn('id', $subjectIds)->get();
    
        return response()->json(['sections' => $sections, 'subjects' => $subjects]);
    }



    public function storeHomeWork(Request $request)
    {
        // dd('hi');
        $request->validate([
            'class_id' => 'required',

        ]);
        try{
            DB::beginTransaction();
            $home_work = New HomeWork();
            $home_work->teacher_id = auth()->user()->id;
            $home_work->name = $request->name;
            $home_work->session_id = $request->session_id;
            $home_work->class_id = $request->class_id;
            $home_work->subject_id = $request->subject_id;
            $home_work->section_id = $request->section_id;
            $home_work->lession_id = $request->lession_id;
            $home_work->page_number = $request->page_number;
            if($request->hasFile('home_workpdf')){
                $fileName = rand().time().'.'.request()->home_workpdf->getClientOriginalExtension();
                request()->home_workpdf->move(public_path('upload/home_work/'),$fileName);
                $home_work->home_workpdf = $fileName;
            }
            // $home_work->image = $request->image;
            $home_work->details = $request->details;
            $home_work->save();
            DB::commit();
            return redirect()->route('instructor.homework.index')->with('message','Home Work Add Successfully');
        }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }

    public function editHomeWork(string $id)
    {
        // dd('hi');
        $data["home_work"]=$home_work= HomeWork::find($id);
        $data['sessions']=Session::orderBy('id', 'desc')->where('status', 1)->get(); 
        $data['teacherAssents']=SubjectTeacherAssent::where('teacher_id', auth()->user()->id)->orderBy('id', 'desc')->where('status', 1)->get(); 
        $data['classs']=Classe::where('id',$home_work->class_id)->orderBy('id', 'desc')->where('status', 1)->get(); 
        $data['subjects']=Subject::where('id',$home_work->subject_id)->orderBy('id', 'desc')->where('status', 1)->get();
        $data['lessions']=Lession::where('id',$home_work->lession_id)->orderBy('id', 'desc')->where('status', 1)->get();
        $data['sections']=SchoolSection::where('id',$home_work->section_id)->orderBy('id', 'desc')->where('status', 1)->get(); 
        return view("user.instructor.home_worke_update",$data);
    }

   
    public function updateHomeWork(Request $request, $id)
    {
        $request->validate([
            'class_id' => 'required',

        ]);
        try{
            DB::beginTransaction();
            $home_work = HomeWork::find($id);
            $home_work->name = $request->name;
            $home_work->teacher_id = auth()->user()->id;
            $home_work->class_id = $request->class_id;
            $home_work->session_id = $request->session_id;
            $home_work->subject_id = $request->subject_id;
            $home_work->section_id = $request->section_id;
            $home_work->lession_id = $request->lession_id;
            $home_work->page_number = $request->page_number;

            if($request->hasFile('home_workpdf')){
                @unlink(public_path("upload/home_work/".$home_work->home_workpdf));
                $fileName = rand().time().'.'.request()->home_workpdf->getClientOriginalExtension();
                request()->home_workpdf->move(public_path('upload/home_work/'),$fileName);
                $home_work->home_workpdf = $fileName;
            }
            $home_work->details = $request->details;
            $home_work->save();

           

            DB::commit();
            return redirect()->route('instructor.homework.index')->with('message','Home Work Update Successfully');
        }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }

    public function destroyHomeWork(Request $request)
    {
        // dd('hi');
        $home_work =  HomeWork::find($request->homework_id);
        @unlink(public_path("upload/home_work/".$home_work->home_workpdf));
        $home_work->delete();
        return redirect()->route('instructor.homework.index')->with('message','Home Work Deleted Successfully');
    }

    public function homeWorkPdfDownload(Request $request,$id)
    {
       $home_work = HomeWork::findOrFail($id);
       if ($home_work->home_workpdf) {
           $filePath = public_path('upload/home_work/'.$home_work->home_workpdf);
           if (file_exists($filePath)) {
               return response()->download($filePath, $home_work->home_workpdf);
           }
       }
       return redirect()->back();
    }

    public function statusHomeWork($id)
    {
        $home_work = HomeWork::find($id);
        if($home_work->status == 0)
        {
            $home_work->status = 1;
        }elseif($home_work->status == 1)
        {
            $home_work->status = 0;
        }
        $home_work->update();
        return redirect()->route('instructor.homework.index');
    }
    // home work End


    // home Class Exam

    public function indexClassExam()
    {
        //dd('hi');
        $data['session']=$currentSession = Session::where('is_current', 1)->first();
        $data['class_tests'] = ClassTestExam::where('teacher_id', auth()->user()->id)
                                        ->where('session_id',$currentSession->id)
                                        ->orderBy('id','desc')
                                        ->get();

        return view('user.instructor.class_exam_index', $data);
    }

    public function createClassExam()
    {
        //  dd('hi');
        $data['sessions'] = Session::where('status', 1)->get();

        $data['teacherAssents'] = SubjectTeacherAssent::where('teacher_id', auth()->user()->id)
        ->where('status', 1)
        ->orderBy('id', 'desc')
        ->get();

        $classIds = $data['teacherAssents']->pluck('class_id')->unique();

        $data['classs'] = Classe::whereIn('id', $classIds)
        ->where('status', 1)
        ->orderBy('id', 'desc')
        ->get();


        return view('user.instructor.class_exam_create', $data);
    }

    public function storeClassExam(Request $request)
    {
        //  dd('hi');
        $request->validate([
            'class_id' => 'required',

        ]);
        try{
            DB::beginTransaction();
            $class_test_exam = New ClassTestExam();
            $class_test_exam->teacher_id = auth()->user()->id;
            $class_test_exam->name = $request->name;
            $class_test_exam->class_id = $request->class_id;
            $class_test_exam->subject_id = $request->subject_id;
            $class_test_exam->section_id = $request->section_id;
            $class_test_exam->session_id = $request->session_id;
            $class_test_exam->lession_id = $request->lession_id;
            $class_test_exam->page_number = $request->page_number;
            $class_test_exam->date = $request->date;
            if($request->hasFile('class_exampdf')){
                $fileName = rand().time().'.'.request()->class_exampdf->getClientOriginalExtension();
                request()->class_exampdf->move(public_path('upload/class_test_exam/'),$fileName);
                $class_test_exam->class_exampdf = $fileName;
            }
            // $home_work->image = $request->image;
            $class_test_exam->class_test_duration = $request->class_test_duration;
            $class_test_exam->details = $request->details;
            $class_test_exam->save();
            DB::commit();
            return redirect()->route('instructor.class_exam.index')->with('message','Class Test Exam Add Successfully');
        }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }

    public function editClassExam(string $id)
    {
        // dd('hi');
        $data["class_test"]=$class_test= ClassTestExam::find($id);
        // $data['classs']=Classe::orderBy('id', 'desc')->where('status', 1)->get(); 
        // $data['subjects']=Subject::orderBy('id', 'desc')->where('status', 1)->get();
        $data['sessions'] = Session::where('status', 1)->get();
        $data['classs']=Classe::where('id',$class_test->class_id)->orderBy('id', 'desc')->where('status', 1)->get(); 
        $data['subjects']=Subject::where('id',$class_test->subject_id)->orderBy('id', 'desc')->where('status', 1)->get();
        $data['lessions']=Lession::where('id',$class_test->lession_id)->orderBy('id', 'desc')->where('status', 1)->get();
        $data['sections']=SchoolSection::where('id',$class_test->section_id)->orderBy('id', 'desc')->where('status', 1)->get(); 
        return view("user.instructor.class_exam_update",$data);
    }


    public function updateClassExam(Request $request, $id)
    {
        $request->validate([
            'class_id' => 'required',

        ]);
        try{
            DB::beginTransaction();
            $class_test_exam = ClassTestExam::find($id);
            $class_test_exam->teacher_id = auth()->user()->id;
            $class_test_exam->name = $request->name;
            $class_test_exam->class_id = $request->class_id;
            $class_test_exam->subject_id = $request->subject_id;
            $class_test_exam->section_id = $request->section_id;
            $class_test_exam->session_id = $request->session_id;
            $class_test_exam->lession_id = $request->lession_id;
            $class_test_exam->page_number = $request->page_number;
            $class_test_exam->date = $request->date;
            if($request->hasFile('class_exampdf')){
                @unlink(public_path("upload/class_test_exam/".$class_test_exam->class_exampdf));
                $fileName = rand().time().'.'.request()->class_exampdf->getClientOriginalExtension();
                request()->class_exampdf->move(public_path('upload/class_test_exam/'),$fileName);
                $class_test_exam->class_exampdf = $fileName;
            }
            $class_test_exam->details = $request->details;
            $class_test_exam->class_test_duration = $request->class_test_duration;
            $class_test_exam->save();

        

            DB::commit();
            return redirect()->route('instructor.class_exam.index')->with('message','Class Exam Update Successfully');
        }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }

    public function destroyClassExam(Request $request)
    {
        // dd('hi');
        $class_test_exam =  ClassTestExam::find($request->class_test_id);
        @unlink(public_path("upload/class_test_exam/".$class_test_exam->class_exampdf));
        $class_test_exam->delete();
        return redirect()->route('instructor.class_exam.index')->with('message','Class Exam Deleted Successfully');
    }

    public function statusClassExam($id)
    {
        $class_test_exam = ClassTestExam::find($id);
        if($class_test_exam->status == 0)
        {
            $class_test_exam->status = 1;
        }elseif($class_test_exam->status == 1)
        {
            $class_test_exam->status = 0;
        }
        $class_test_exam->update();
        return redirect()->route('instructor.class_exam.index');
    }
    // home Class Exam


    // Result Exam start
    public function createResultExam()
    {
        // dd('hi');
        $data['examinations']=Examination::orderBy('id', 'desc')->get();
        $data['teacherAssents']=SubjectTeacherAssent::where('teacher_id',auth()->user()->id)->get();
        return view('user.instructor.exam_result_create',$data);
    }

       //ajax get Teacher Assent class
    public function getTeacherAssentClass($id){
        $classes = ExamClass::where("examination_id", $id)->with('class')->get();
        // Retrieve unique class IDs associated with the teacher
        
        $classIds = SubjectTeacherAssent::where('teacher_id', auth()->user()->id)
            ->whereIn('class_id', $classes->pluck('class_id'))
            ->pluck('class_id')
            ->unique();

        $class = Classe::whereIn('id', $classIds)->get();                                      

        return $class;
	} 

    public function indexResultExam()
    {
        // dd('hi');
        $data['teacherAssents']=$teacherAssents=SubjectTeacherAssent::where('teacher_id',auth()->user()->id)->first();
        // dd($teacherAssents);
        $data['results']=ExamResult::where('teacher_id',$teacherAssents->teacher_id)
                                         ->orWhere('class_id',$teacherAssents->class_id)
                                         ->orwhere('section_id',$teacherAssents->section_id)
                                         ->orwhere('session_id',$teacherAssents->session_id)
                                         ->orwhere('subject_id',$teacherAssents->subject_id)
                                        ->orderBy('id', 'desc')->get();
        // dd($data);
        $data['classes'] = Classe::where('status', 1)->get();
        $data['sessions'] = Session::where('status', 1)->get();
        $data['sections'] = SchoolSection::where('status', 1)->get();
        $data['examinations'] = Examination::where('status', 1)->get();
        return view('user.instructor.exam_result_index',$data);
    }
   
    function getTeacherResultByAjax(Request $request){
        // dd($request->all());
         $columns = array(
            0 => 'id',
            1 => 'examination_id',
            2 => 'class_id',
            3 => 'roll_number',
            4 => 'student_id',
            5 => 'session_id',
            6 => 'section_id',
            7 => 'marke',
            8 => 'pass_marke',
            9 => 'obtained_marke',
            10 => 'options',
           
        );
        
        $totalData = ExamResult::count();
        $totalFiltered = $totalData;
 
        $limit = $request->input('length');
        $start = $request->input('start');
        // dd($request->input('order.0.column'));
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $teacherAssents=SubjectTeacherAssent::where('teacher_id',auth()->user()->id)->first();
        $results = ExamResult::where('teacher_id',$teacherAssents->teacher_id);
                                                    // ->orWhere('class_id',$teacherAssents->class_id)
                                                    // ->orwhere('section_id',$teacherAssents->section_id)
                                                    // ->orwhere('session_id',$teacherAssents->session_id)
                                                    // ->orwhere('subject_id',$teacherAssents->subject_id)
                                                    // ->orderBy('id', 'desc');


        // $results = ExamResult::where('is_publis',0);                                     

        if(!empty($search)){
            $results =$results->where("obtained_marke","LIKE","%{$search}%");
        }
        if($request->examination_id !=''){
            $results =$results->where("examination_id",$request->examination_id);
        }
        if($request->session_id !=''){
            $results =$results->where("session_id",$request->session_id);
        }
        if($request->class_id !=''){
            $results =$results->where("class_id",$request->class_id);
        }
        if($request->section_id !=''){
            $results =$results->where("section_id",$request->section_id);
        }
         
 
        $results = $results->offset($start)->limit($limit)->orderBy($order,$dir)->get();
        $totalFiltered = $results->count();
 
        $data = array();
        if(!empty($results))
        {
             $i = $start == 0 ? 1 : $start+1;
            foreach($results as $result)
            {
                $nestedData['id'] = $i++;
                $nestedData['examination_id'] = $result->examination->name;
                $nestedData['class_id'] = $result->class->name;
                $nestedData['roll_number'] = $result->roll_number;
                $nestedData['student_id'] = $result->student->student_name;
                $nestedData['session_id'] = $result->session->start_year ." - ". $result->session->end_year;
                $nestedData['section_id'] = $result->section->name;
                $nestedData['marke'] = $result->marke;
                $nestedData['pass_marke'] = $result->pass_marke;
                $nestedData['obtained_marke'] = $result->obtained_marke;

                $nestedData['options'] = '<a class="btn btn-primary data_edit" href="'.route('instructor.exam_result.edit', $result->id).'"><i class="fa fa-edit"></i></a>';

                $data[] = $nestedData;
 
            }
        }
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"            => $data
        );
 
        return json_encode($json_data);
    }


    public function editResultExam($id)
    {
        $data['examResult']=ExamResult::find($id);
        // $data['teacherAssents']=SubjectTeacherAssent::where('teacher_id',auth()->user()->id)->get();
        return view('user.instructor.exam_result_update',$data);
    }

    public function updateResultExam(Request $request, $id)
    {
        $request->validate([
            'obtained_marke' => 'required',
        ]);
        try{
            DB::beginTransaction();
            $examResult = ExamResult::find($id);
            $examResult->obtained_marke = $request->obtained_marke;    
            $examResult->save();
            DB::commit();
            return redirect()->route('instructor.exam_result.index')->with('message','Exam Result Update Successfully');
        }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }


    //ajax get subject
    public function getTeacherAssentSubject($classId,$sectionId){
        // $subject = SubjectTeacherAssent::where("class_id",$id)->where('teacher_id',auth()->user()->id)->with('subject')->get();

        $subject = SubjectTeacherAssent::where("class_id",$classId)->where('section_id',$sectionId)->where('teacher_id',auth()->user()->id)->with('subject')->get();

        $subjectIds = SubjectTeacherAssent::where('teacher_id', auth()->user()->id)
        ->whereIn('subject_id', $subject->pluck('subject_id'))
        ->where('section_id',$sectionId)
        ->pluck('subject_id')
        ->unique();
    
        $subject = Subject::whereIn('id', $subjectIds)->get(); 

        return $subject;
	}  

     //ajax get Teacher Assent School Section
    public function getTeacherAssentSchoolSection($id){
        // $section = SubjectTeacherAssent::where("class_id",$id)->where('teacher_id',auth()->user()->id)->with('schoolsection')->get();
       
        $section = SubjectTeacherAssent::where("class_id",$id)->where('teacher_id',auth()->user()->id)->with('schoolsection')->get();
       
        $sectionIds = SubjectTeacherAssent::where('teacher_id', auth()->user()->id)
        ->whereIn('section_id', $section->pluck('section_id'))
        ->pluck('section_id')
        ->unique();

        $section = SchoolSection::whereIn('id', $sectionIds)->get(); 

        return $section;
	}  

     //ajax get Teacher Assent School Section
     public function getTeacherAssentSession($id){
        $session = SubjectTeacherAssent::where("class_id",$id)->where('teacher_id',auth()->user()->id)->with('session')->get();

        $sessionIds = SubjectTeacherAssent::where('teacher_id', auth()->user()->id)
        ->whereIn('session_id', $session->pluck('session_id'))
        ->pluck('session_id')
        ->unique();
        // Retrieve unique classes based on the filtered class IDs
        $session = Session::whereIn('id', $sessionIds)->get(); 
        return $session;
	}  


    // public function getTeacherAssentResult(Request $request)
    // {
    //     $examinationId = $request->input('examination_id');
    //     $classId = $request->input('class_id');
    //     $sectionId = $request->input('section_id');
    //     $sessionId = $request->input('session_id');
    //     $subjectId = $request->input('subject_id');
    //     // return response()->json(['examination_id' => $examinationId,'classId' => $classId,'sectionId' => $sectionId,'subject_id' => $subjectId,'sessionId' => $sessionId]);
    //     if( $classId && $sectionId && $sessionId && $examinationId && $subjectId){
    //         $data['students']=$students = Admission::where('class_id',$classId)->where('section_id', $sectionId)->where('session_id', $sessionId)->get();
    //         $data['Examclass']= ExamClass::where('examination_id',$examinationId)->where("class_id",$classId)->where('subject_id',$subjectId)->first();
    //         $data['examResult']= ExamResult::where('examination_id',$examinationId)->where("class_id",$classId)->where('subject_id',$subjectId)->first();
    //     }
    //     // elseif( $classId && $sessionId && $examinationId && $subjectId){
    //     //     $data['students']=$students = Admission::where('class_id',$classId)->where('session_id', $sessionId)->get();
    //     //     $data['Examclass']= ExamClass::where('examination_id',$examinationId)->where("class_id",$classId)->where('subject_id',$subjectId)->first();
    //     // }
        
    //     return view('user.instructor.student_show',$data);
    // }



    public function getTeacherAssentResult(Request $request)
    {
        $examinationId = $request->input('examination_id');
        $classId = $request->input('class_id');
        $sectionId = $request->input('section_id');
        $sessionId = $request->input('session_id');
        $subjectId = $request->input('subject_id');

        if ($classId && $sectionId && $sessionId && $examinationId && $subjectId) {
            $data['students'] = $students = Admission::where('class_id', $classId)
                ->where('section_id', $sectionId)
                ->where('session_id', $sessionId)
                ->get();
            
            $data['Examclass'] = $examClass = ExamClass::where('examination_id', $examinationId)
                ->where('class_id', $classId)
                ->where('subject_id', $subjectId)
                ->first();

            $studentIds = $students->pluck('id');
            $data['examResults'] = ExamResult::where('examination_id', $examinationId)
                ->whereIn('student_id', $studentIds)
                ->where('subject_id', $subjectId)
                ->get()
                ->keyBy('student_id');
        }

        return view('user.instructor.student_show', $data);
    }


    public function storeStudentResult(Request $request)
    {
        $request->validate([
            'obtained_marke' => 'required|array',
            'obtained_marke.*' => 'required|numeric|min:0', 
        ]);

        try {
            DB::beginTransaction();

            foreach ($request->obtained_marke as $studentId => $marks) {
                $examResult = ExamResult::where('student_id', $studentId)
                    ->where('examination_id', $request->examination_id[$studentId])
                    ->where('subject_id', $request->subject_id[$studentId])
                    ->first();

                if ($examResult) {
                    $examResult->obtained_marke = $marks;
                } else {
                    $examResult = new ExamResult();
                    $examResult->student_id = $studentId;
                    $examResult->obtained_marke = $marks;
                    $examResult->roll_number = $request->roll_number[$studentId] ?? 0;
                    $examResult->class_id = $request->class_id[$studentId] ?? 0;
                    $examResult->session_id = $request->session_id[$studentId] ?? 0;
                    $examResult->section_id = $request->section_id[$studentId] ?? 0;
                    $examResult->subject_id = $request->subject_id[$studentId] ?? 0;
                    $examResult->academic_year_id = $request->academic_year_id[$studentId] ?? 0;
                    $examResult->marke = $request->marke[$studentId] ?? 0;
                    $examResult->pass_marke = $request->pass_marke[$studentId] ?? 0;
                    $examResult->examination_id = $request->examination_id[$studentId] ?? 0;
                    $examResult->exam_class_id = $request->exam_class_id[$studentId] ?? 0;
                    $examResult->teacher_id = auth()->user()->id;
                    $examResult->is_publis = '0';
                }

                $examResult->save();
            }

            DB::commit();
            return redirect()->route('instructor.exam_result.index')->with('message', 'Exam Result Add/Updated Successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error_message', $e->getMessage());
        }
    }
   // Result Exam end


   // Daily Class Start
    public function indexDailyClass()
    {
        $data['session']=$currentSession = Session::where('is_current', 1)->first();
        $data['daily_classes'] = DailyClass::where('teacher_id', auth()->user()->id)
                                        ->where('session_id',$currentSession->id)
                                        ->orderBy('id','desc')
                                        // ->where('status', 1)
                                        ->get();
        // $data['daily_classes'] = DailyClass::where('teacher_id',auth()->user()->id)->orderBy('id', 'desc')->get();
        return view('user.instructor.daily_class_index', $data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function createDailyClass()
    {
        // dd('hi');
        // $data['daily_classes'] = DailyClass::where('status','1')->orderBy('id', 'desc')->get();
        // $data['teachers'] = User::where('type','2')->where('status','1')->orderBy('id', 'desc')->get();
        // $data['classes'] = Classe::where('status','1')->orderBy('id', 'asc')->get();
       
        $data['sessions'] = Session::where('status', 1)->get();

        $data['teacherAssents'] = SubjectTeacherAssent::where('teacher_id', auth()->user()->id)
                                                        ->where('status', 1)
                                                        ->orderBy('id', 'desc')
                                                        ->get();

        $classIds = $data['teacherAssents']->pluck('class_id')->unique();

        $data['classes'] = Classe::whereIn('id', $classIds)
                                    ->where('status', 1)
                                    ->orderBy('id', 'desc')
                                    ->get();
        return view("user.instructor.daily_class_create",$data);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function storeDailyClass(Request $request)
    {
    //    dd($request->all());
        $request->validate([
            'class_id' => 'required',
            'lession_id' => 'required',

        ]);
        try{
            DB::beginTransaction();
            $daily_class = new DailyClass();
            $daily_class->name = $request->name ?? "";
            // $daily_class->teacher_id = $request->teacher_id ?? 0;
            $daily_class->teacher_id = auth()->user()->id ?? 0;
            $daily_class->class_id = $request->class_id ?? 0;
            $daily_class->subject_id = $request->subject_id ?? 0;
            $daily_class->session_id = $request->session_id ?? 0;
            $daily_class->section_id = $request->section_id ?? 0;
            $daily_class->group_id = $request->group_id ?? 0;
            $daily_class->video_url = "https://" . preg_replace('#^https?://#', '',$request->video_url);
            $daily_class->lession_id = $request->lession_id ?? 0;
            $daily_class->page_number = $request->page_number ?? 0;
            $daily_class->sub_banner = $request->sub_banner ?? 1;
            $daily_class->details = $request->details ?? "";


            if($request->hasFile('video')){
                $fileName = rand().time().'.'.request()->video->getClientOriginalExtension();
                request()->video->move(public_path('upload/daily_class/'),$fileName);
                $daily_class->video = $fileName;
            }
    
            // if($request->hasFile('video_thumbnail')){
            //     $fileName = rand().time().'.'.request()->video_thumbnail->getClientOriginalExtension();
            //     request()->video_thumbnail->move(public_path('upload/daily_class/'),$fileName);
            //     $daily_class->video_thumbnail = $fileName;
            // }

            $daily_class->save();

            DB::commit();
            return redirect()->route('instructor.daily_class.index')->with('message','Daily Class Add Successfully');
        }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function editDailyClass(string $id)
    {
       // dd('hi');
       $data['daily_class'] = $daily_class = DailyClass::find($id);
       $data['teachers'] = User::where('type','2')->where('status','1')->orderBy('id', 'desc')->get();
       $data['sessions'] = Session::where('status', 1)->get(); 

       $data['classes'] = Classe::where('id',$daily_class->class_id)->where('status','1')->orderBy('id', 'asc')->get();
       $data['classs']=Classe::where('id',$daily_class->class_id)->orderBy('id', 'desc')->where('status', 1)->get(); 
       $data['subjects']=Subject::where('id',$daily_class->subject_id)->orderBy('id', 'desc')->where('status', 1)->get();
       $data['lessions']=Lession::where('id',$daily_class->lession_id)->orderBy('id', 'desc')->where('status', 1)->get();
       $data['sections']=SchoolSection::where('id',$daily_class->section_id)->orderBy('id', 'desc')->where('status', 1)->get(); 
 
        return view("user.instructor.daily_class_update",$data);
    }

    /**
     * Update the specified resource in storage.
     */
    public function updateDailyClass(Request $request, string $id)
        {
            //dd($request->all());
        $request->validate([
            'class_id' => 'required',
            'lession_id' => 'required',

        ]);
        try{
            DB::beginTransaction();
            $daily_class = DailyClass::find($id);
            $daily_class->name = $request->name ?? "";
            // $daily_class->teacher_id = $request->teacher_id ?? 0;
            $daily_class->teacher_id = auth()->user()->id ?? 0;
            $daily_class->class_id = $request->class_id ?? 0;
            $daily_class->subject_id = $request->subject_id ?? 0;
            $daily_class->session_id = $request->session_id ?? 0;
            $daily_class->section_id = $request->section_id ?? 0;
            $daily_class->group_id = $request->group_id ?? 0;
            $daily_class->video_url = "https://" . preg_replace('#^https?://#', '',$request->video_url);
            $daily_class->lession_id = $request->lession_id ?? 0;
            $daily_class->page_number = $request->page_number ?? 0;
            $daily_class->sub_banner = $request->sub_banner ?? 1;
            $daily_class->details = $request->details ?? "";

            if($request->hasFile('video')){
                @unlink(public_path("upload/daily_class/".$daily_class->video));
                $fileName = rand().time().'.'.request()->video->getClientOriginalExtension();
                request()->video->move(public_path('upload/daily_class/'),$fileName);
                $daily_class->video = $fileName;
            }

            // if($request->hasFile('video_thumbnail')){
            //     @unlink(public_path("upload/daily_class/".$daily_class->video_thumbnail));
            //     $fileName = rand().time().'.'.request()->video_thumbnail->getClientOriginalExtension();
            //     request()->video_thumbnail->move(public_path('upload/daily_class/'),$fileName);
            //     $daily_class->video_thumbnail = $fileName;
            // }

            $daily_class->save();

            DB::commit();
            return redirect()->route('instructor.daily_class.index')->with('message','Daily Class Update Successfully');
        }catch(\Exception $e){
            DB::rollBack();
            dd($e);
            return back()->with ('error_message', $e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroyDailyClass(Request $request)
    {

        $daily_class =  DailyClass::find($request->daily_class_id);
        @unlink(public_path("upload/daily_class/".$daily_class->video));
        // @unlink(public_path("upload/daily_class/".$daily_class->video_thumbnail));
        $daily_class->delete();
        return back()->with('message','Daily Class Deleted Successfully');
    }


    public function statusDailyClass($id)
    {
        $daily_class = DailyClass::find($id);
        if($daily_class->status == 0)
        {
            $daily_class->status = 1;
        }elseif($daily_class->status == 1)
        {
            $daily_class->status = 0;
        }
        $daily_class->update();
        return redirect()->route('instructor.daily_class.index');
    }
   // Daily Class End

}
