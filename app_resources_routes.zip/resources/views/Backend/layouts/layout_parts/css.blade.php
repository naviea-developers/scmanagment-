<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet"  href="https://site-assets.fontawesome.com/releases/v6.2.1/css/all.css">


<!--- start  -->
    {{-- @vite(['resources/css/app.css', 'resources/js/app.js']) --}}

     <link rel="preload" as="style" href="{{ asset('public') }}/build/assets/app-bde4493b.css"/>
     <link rel="modulepreload" href="{{ asset('public') }}/build/assets/app-6870bb4e.js" />
     <link rel="stylesheet" href="{{ asset('public') }}/build/assets/app-bde4493b.css" />
     <script type="module" src="{{ asset('public') }}/build/assets/app-6870bb4e.js"></script>
<!-- start vendor css -->
    <link href="{{asset('public/backend')}}/lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="{{asset('public/backend')}}/lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <link href="{{asset('public/backend')}}/lib/rickshaw/rickshaw.min.css" rel="stylesheet">
    {{-- <link href="{{asset('public/backend')}}/lib/select2/css/select2.min.css" rel="stylesheet"> --}}

    <!-- start form editor Css -->
	<link href="{{asset('public/backend')}}/lib/highlightjs/styles/github.css" rel="stylesheet">
    <link href="{{asset('public/backend')}}/lib/medium-editor/css/medium-editor.min.css" rel="stylesheet">
    <link href="{{asset('public/backend')}}/lib/medium-editor/css/themes/default.min.css" rel="stylesheet">
    <link href="{{asset('public/backend')}}/lib/summernote/summernote-bs4.css" rel="stylesheet">
    <!-- start form editor Css -->

    <!-- start datatable css--->
    <link href="{{asset('public/backend')}}/lib/datatables.net-dt/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="{{asset('public/backend')}}/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css" rel="stylesheet">

    <!-- End Vendor css -->

    <!-- Start Bracket CSS -->
    <link rel="stylesheet" href="{{asset('public/backend')}}/css/bracket.css">
    <!-- End Bracket CSS -->
   <link rel="stylesheet" href="{{asset('public/backend')}}/css/suneditor.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />



